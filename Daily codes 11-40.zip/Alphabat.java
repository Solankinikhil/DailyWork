package com.cts.training1;

import java.util.Scanner;

public class Alphabat {
	public static void main(String[] args)
	{
		
		Scanner scanner = new Scanner(System. in);
		System. out. println("Input the character: ");
		
		char c = scanner. next(). charAt(0);

		if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
			System.out.println(c + " is an alphabet: ");
		else
			System.out.println(c + " is not an alphabet: ");
	}
}