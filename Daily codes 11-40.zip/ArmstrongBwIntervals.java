package com.cts.training1;

import java.util.Scanner;

public class ArmstrongBwIntervals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first no f1:");
		int f1 = sc.nextInt();
		System.out.println("Enter last no l1 :");
		int l1 = sc.nextInt();

		for (int number = l1 + 1; number < f1; ++number) {
			int digits = 0;
			int result = 0;
			int originalNumber = number;

			while (originalNumber != 0) {
				originalNumber /= 10;
				++digits;
			}

			originalNumber = number;

			while (originalNumber != 0) {
				int remainder = originalNumber % 10;
				result += Math.pow(remainder, digits);
				originalNumber /= 10;
			}

			if (result == number)
				System.out.print(number + " ");
		}

	}
}
