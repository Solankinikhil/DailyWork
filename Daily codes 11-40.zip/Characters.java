package com.cts.training1;

public class Characters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char C;

        for(C = 'A'; C <= 'Z'; ++C)
            System.out.print(C + " ");
	}

}
