package com.cts.training;
import java.util.Scanner; 
public class Fibonacci {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);  
        System.out.print("Enter a number : ");  
        int num = s.nextInt(); 
        int  t1 = 0, t2 = 1;
			
        System.out.print("First " + num + " terms: ");
        for (int i = 1; i <= num; ++i)
        {
            System.out.print(t1 + " + ");
            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
        }

	}

}
