package com.cts.training1;

import java.util.Scanner;

public class GcdUsingRecurssion {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number n1 :");
		int n1 = sc.nextInt();

		System.out.println("Enter number n2 :");
		int n2 = sc.nextInt();

		int hcf = hcf(n1, n2);

		System.out.printf("G.C.D of %d and %d is %d.", n1, n2, hcf);
	}

	public static int hcf(int n1, int n2) {
		if (n2 != 0)
			return hcf(n2, n1 % n2);
		else
			return n1;
	}

}