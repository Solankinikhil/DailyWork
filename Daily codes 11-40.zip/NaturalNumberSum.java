package com.cts.training1;

import java.util.Scanner;

public class NaturalNumberSum {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Input the Number up to which u want sum: ");

		int num = scanner.nextInt();
		int sum = 0;
		for (int i = 1; i <= num; i++) {
			sum = sum + i;

		}
		System.out.println("Sum up to " + num + " is: " + sum);
	}

}
