package com.cts.training1;

import java.util.Scanner;

public class PositiveNegative {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number:");
		
		double n=sc.nextDouble();
		
		if(n>0.0)
		
			System.out.println(n+ " is positive no");
		else if(n<0.0)
			System.out.println(n+ " is negative no");
		else
			System.out.println(n+ " is 0");

	}

}
