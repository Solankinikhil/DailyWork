package com.cts.training1;

import java.util.Scanner;

public class PowerOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Base :");
		int base = sc.nextInt();
		System.out.println("Enter exponent :");
		int exponent = sc.nextInt();
		
		long result =1;
		while (exponent != 0)
        {
            result = result*base;
            exponent--;
        }

        System.out.println("Answer = " + result);
		
	}

}
