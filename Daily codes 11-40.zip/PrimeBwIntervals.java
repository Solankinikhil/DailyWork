package com.cts.training1;

import java.util.Scanner;

public class PrimeBwIntervals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first no:");
		int f1 = sc.nextInt();
		System.out.println("Enter last no :");
		int l1 = sc.nextInt();

		while (l1 < f1) {
			boolean flag = false;

			for (int i = 2; i <= l1 / 2; ++i) {

				if (l1 % i == 0) {
					flag = true;
					break;
				}
			}

			if (!flag)
				System.out.print(l1 + " ");

			++l1;
		}
	}

}
