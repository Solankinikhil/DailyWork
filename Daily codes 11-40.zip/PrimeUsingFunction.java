package com.cts.training1;

import java.util.Scanner;

public class PrimeUsingFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first no f1:");
		int f1 = sc.nextInt();
		System.out.println("Enter last no l1 :");
		int l1 = sc.nextInt();
		//f1 should be > than l1
		while (l1 < f1) {
            if(checkPrimeNumber(l1))
                System.out.print(l1 + " ");

            ++l1;
        }
    }

    public static boolean checkPrimeNumber(int num) {
        boolean flag = true;

        for(int i = 2; i <= num/2; ++i) {

            if(num % i == 0) {
                flag = false;
                break;
            }
        }

        return flag;
	}

}
