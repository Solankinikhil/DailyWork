package com.cts.training1;

import java.util.Scanner;

public class SumofNaturalNumberUsingRecurssion {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number :");
		int number = sc.nextInt();

		int sum = addNumbers(number);
		System.out.println("Sum = " + sum);
	}

	public static int addNumbers(int num) {
		if (num != 0)
			return num + addNumbers(num - 1);
		else
			return num;
	}

}
