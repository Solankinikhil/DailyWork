package com.cts.training;

public class Add {
	public static void main(String[] args)
	{	int a = 50,b=35;
		int Sum=a+b;
		
		System.out.println("Addition result:"+Sum);
	}
}
