package com.cts.training;

public class Asciivalue {
	public static void main(String[] args) {
		
		char ch='n';
		int ascii=ch;
		
		int castascii=(int)ch;
		System.out.println("Ascii value of "+ ch + " is:"+castascii);
	}
	
}
