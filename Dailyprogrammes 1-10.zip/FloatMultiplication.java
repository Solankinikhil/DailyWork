package com.cts.training;

public class FloatMultiplication {
	public static void main(String[] args)
	{
		float a=2.5f;
		float b=4.5f;
		
		float result=a*b;
		System.out.println("Product Result:"+result);
	}
}
