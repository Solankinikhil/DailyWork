package com.cts.training;

import java.util.Scanner;

public class PrintInteger {
	public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Integer:");
	
	int num=sc.nextInt();
	
	System.out.println("you intered integer:"+num);
			
}
}