package com.cts.training;

public class QuotientRemainder {
	public static void main(String[] args)
	{
		int divident=100, divisor=25;
		
		int quotient=divident/divisor;
		int remainder=divident%divisor;
		
		System.out.println("quotient= "+quotient);
		System.out.println("remainder= "+remainder);
	}
}
