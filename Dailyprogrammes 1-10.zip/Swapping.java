package com.cts.training;

public class Swapping {
	public static void main(String[] args) 
	{
		int a=30,b=50;
		
		System.out.println("Before swap:a="+a +" b=" +b);
		
		a=a-b;//20//30
		b=a+b;//70
		a=b-a;//50
		
		System.out.println("After swap:a="+a +" b=" +b);
	}
}
